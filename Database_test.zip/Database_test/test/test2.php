<?php


if(isset($comment_from_user)) {
    foreach ($comment_from_user as $value) {
        echo $value;
        echo $value;
        echo $value . '<br>';
    }
}


echo '<script>';
echo 'alert("You can not ")';
echo '</script>'


?>
<!---->
<!--<script>-->
<!--    alert("欢迎！请按“确定”继续。");-->
<!--</script>-->
