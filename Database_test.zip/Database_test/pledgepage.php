<?php

echo 'this is good';

$projectname = $_GET["projectname"];
echo $projectname;

?>