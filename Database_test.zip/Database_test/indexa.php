<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="Database_Final/diseaseadd.inc.php method="POST">
<input type="text" name="deid" placeholder= "diseaseid id">
<br>
<input type="text" name="dename" placeholder = "disease name ">
<br>
<button type="submit" name ="submit">add more</button>


</form>
</body>
</html>